<head>
    <link rel="stylesheet" type="text/css" href="style.css">
    
    <script src="http://code.jquery.com/jquery-3.4.1.min.js"></script>
</head>
<body>

<?php
include"header.php";
include"content.php";
include"Footer.php";
include"java.php";
?>

</body>