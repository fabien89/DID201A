<h2>Developer Inspector Tools
</h2>

<p>Browsers has useful tool for web developers, one of them is the inspector tool. What is this tool for? Well, this tool can show you the tree of the a web page that is online, HTML, and CSS, also shows the time takes to download each element, so handy if you are trying to reduce delay times.</p>

<p>The inspector tool, also allow you to do editions in the CSS file and real time visualisation, 
Helpful for front-end developers as when you are building a web page it does not show you the real visualisation when it is not online or in the server, it always change a bite or some things do not work as expected. </p>

<p>Great tool to find mistakes, because you can click in what you thing is wrong and show you the exact line it is the Style class on the file, web developer are thankful, as you do not need to search in the file that can contain over a thousand lines or even more. This tool helps to learn of other people works.</p>

<p>There are few differences between these tools in different browsers; most of them have same features, as an example safari, chrome or Mozilla. </p>