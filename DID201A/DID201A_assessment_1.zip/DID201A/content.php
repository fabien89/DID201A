
<div class="Container">
<div class="Content">
    <article class="art" id="tab1"><?php
    include"article1.php";
    ?></article>
    <article class="art" id="tab2"><?php
    include"article2.php";
    ?></article>
    <article class="art" id="tab3"><?php
    include"article3.php";
    ?></article>
    
</div>
<div class="Rightpanel">
    <ul class="panels">
        <li><a href="#tab1" class="button">Article 1</a></li>
        <li><a href="#tab2" class="button">Article 2</a></li>
        <li><a href="#tab3" class="button">Article 3</a></li>
        
    </ul>
</div>
</div>