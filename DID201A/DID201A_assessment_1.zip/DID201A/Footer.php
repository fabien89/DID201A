<div class="foot">
    <h1><?php
echo date("D, M, Y");
?></h1>
</div>