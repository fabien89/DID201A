<script>
    $(document).ready(function(){
        $('ul.tabs li a:first').addClass('active');
        $('.Content article').hide();
        $('.Content article:first').show();
        
        $('ul.tabs li a').click(function(){
            $('ul.tabs li a').removeClass('active');
            $(this).addClass('active');
            $('.Content article').hide();
            
            var activeTab = $(this).attr('href');
            $(activeTab).show();
            return false;
        });
    });
    
    $(document).ready(function(){
        $('ul.panels li a:first').addClass('active');
        $('.Content article').hide();
        $('.Content article:first').show();
        
        $('ul.panels li a').click(function(){
            $('ul.panels li a').removeClass('active');
            $(this).addClass('active');
            $('.Content article').hide();
            
            var activeTab = $(this).attr('href');
            $(activeTab).show();
            return false;
        });
    });
    
</script>