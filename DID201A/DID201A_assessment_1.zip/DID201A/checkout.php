<head>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php
echo $_GET['body'];
?>
<br>

<div class="result">
    <p>start-Date Submitted:</p>
<div class="inputDate">
<a>
<?php
echo $_GET['startDate'];
?></a>
</div>
<br>
</br>
    <p>end-Date Submitted:</p>
<div class="inputDate">
  <a>  
<?php
echo $_GET['endDate'];
?>
</a>
</div>
<br>


    <p>new page</p>
</div>
</body>