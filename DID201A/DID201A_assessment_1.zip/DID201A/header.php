
<div class="header">
    <ul class="tabs">
        <li><a href="#tab1" class="button">Article 1</a></li>
        <li><a href="#tab2" class="button">Article 2</a></li>
        <li><a href="#tab3" class="button">Article 3</a></li>
        
    </ul>
</div>