<h2>What happens when click on a link?</h2>

<p>Search on the internet can sound pretty easy, but what if I can tell you, technically it is not that easy and can be a bite complicate even to understand it. To initiate we need to find out what happened when clicking on a link and what the process is behind the browser.</p>

<p>The processor start by clicking on the link that you have or you had obtained from someone or somewhere, by clicking you had allow the browser to read and check the link, slitting the ling in sections, then the browser has to communicated to the DNS to obtain the IP address, when this processes came back to the browser, then the browser redirect to the IP address where it is store all the information of the link that you have clicked before, and the download start on the browser and translate it in to HTML for you to visualise it.</p>

<p>For a better understanding, lets explain in sections:</p>

<p>DNS is Domain Name System and contain 4 server, DNS recursor, which is involved to collect the information of all servers and also the queries required of the browser. Root name-server it is the server that translate from the name to IP address. TLD nameserver it is the second step after the root-server, the TLD is in charge to search where was the last time the name of the link was host on the servers, it means TLD is the “com” in the name domain. Authoritative name-server is the last step of the search and it will return into the exact IP address and give it to the DNS.</p>
<?php$content = file_get_contents("https://cdn-images-1.medium.com/max/800/0*yC9oY647Pggg817o.png");
echo $content;?>
<p>IP address it is the Internet Protocol Address, it is a unique address that every router or dispositive connected to internet has, giving an example, it is like your phone number or the address of your house or postal mail address. With this number, the browser can communicate to the place that whatever you are searching for it is store (the information).</p>