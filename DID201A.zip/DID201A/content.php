<?php $txt = "just want to test";
?>
<p>paragraph</p> 

<?php
echo " $txt ";
?>